function showinfo(sid)
		{
		
		for (var i=0; i < document.all.length; i++)
		{
			if (document.all.item(i).id.indexOf("comic")==0 
				&& document.all.item(i).id != "comic" + sid)
				document.all.item(i).style.display = "none";
		}
		whichEl = eval("comic" + sid);
		if (whichEl.style.display == "none")
		{
		eval("comic" + sid + ".style.display=\"\";");
		}
		
		if (sid=="1")
		{
		document.all.readcomic.src="/images/common/05-02-button-01-action.png";
		document.all.download.src="/images/common/05-02-button-02-back.png";
		document.all.readComment.src="/images/common/05-02-button-03-back.png";
		document.all.Comment.src="/images/common/05-02-button-04-back.png";
		}
		if (sid=="2")
		{
	document.all.readcomic.src="/images/common/05-02-button-01-back.png";
		document.all.download.src="/images/common/05-02-button-02-action.png";
		document.all.readComment.src="/images/common/05-02-button-03-back.png";
		document.all.Comment.src="/images/common/05-02-button-04-back.png";
		}
		if (sid=="3")
		{
			document.all.readcomic.src="/images/common/05-02-button-01-back.png";
		document.all.download.src="/images/common/05-02-button-02-back.png";
		document.all.readComment.src="/images/common/05-02-button-03-action.png";
		document.all.Comment.src="/images/common/05-02-button-04-back.png";
		}
		if (sid=="4")
		{
		document.all.readcomic.src="/images/common/05-02-button-01-back.png";
		document.all.download.src="/images/common/05-02-button-02-back.png";
		document.all.readComment.src="/images/common/05-02-button-03-back.png";
		document.all.Comment.src="/images/common/05-02-button-04-action.png";
		}		
		
		}
			
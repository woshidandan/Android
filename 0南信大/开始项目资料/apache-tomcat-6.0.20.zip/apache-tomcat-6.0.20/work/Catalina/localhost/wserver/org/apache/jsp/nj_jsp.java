package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class nj_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json; charset=utf-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("{\"reason\":\"successed!\",\"result\":{\"data\":{\"realtime\":{\"city_code\":\"101190101\",\"city_name\":\"南京\",\"date\":\"2016-08-23\",\"time\":\"07:00:00\",\"week\":2,\"moon\":\"七月廿一\",\"dataUptime\":1471907823,\"weather\":{\"temperature\":\"27\",\"humidity\":\"88\",\"info\":\"多云\",\"img\":\"1\"},\"wind\":{\"direct\":\"东风\",\"power\":\"2级\",\"offset\":null,\"windspeed\":null}},\"life\":{\"date\":\"2016-8-23\",\"info\":{\"chuanyi\":[\"炎热\",\"天气炎热，建议着短衫、短裙、短裤、薄型T恤衫等清凉夏季服装。\"],\"ganmao\":[\"少发\",\"各项气象条件适宜，发生感冒机率较低。但请避免长期处于空调房间中，以防感冒。\"],\"kongtiao\":[\"部分时间开启\",\"您将感到些燥热，建议您在适当的时候开启制冷空调来降低温度，以免中暑。\"],\"wuran\":[\"良\",\"气象条件有利于空气污染物稀释、扩散和清除，可在室外正常活动。\"],\"xiche\":[\"较适宜\",\"较适宜洗车，未来一天无雨，风力较小，擦洗一新的汽车至少能保持一天。\"],\"yundong\":[\"较适宜\",\"天气较好，但由于风力较大，推荐您在室内进行低强度运动，若在户外运动请注意避风。\"],\"ziwaixian\":[\"中等\",\"属中等强度紫外线辐射天气，外出时建议涂擦SPF高于15、PA+的防晒护肤品，戴帽子、太阳镜。\"]}},\"weather\":[{\"date\":\"2016-08-23\",\"info\":{\"day\":[\"1\",\"多云\",\"34\",\"东风\",\"3-4 级\",\"05:34\"],\"night\":[\"1\",\"多云\",\"24\",\"东风\",\"微风\",\"18:40\"]},\"week\":\"二\",\"nongli\":\"七月廿一\"},{\"date\":\"2016-08-24\",\"info\":{\"dawn\":[\"1\",\"多云\",\"24\",\"东风\",\"微风\",\"18:40\"],\"day\":[\"1\",\"多云\",\"34\",\"东风\",\"3-4 级\",\"05:35\"],\"night\":[\"1\",\"多云\",\"25\",\"东风\",\"3-4 级\",\"18:39\"]},\"week\":\"三\",\"nongli\":\"七月廿二\"},{\"date\":\"2016-08-25\",\"info\":{\"dawn\":[\"1\",\"多云\",\"25\",\"东风\",\"3-4 级\",\"18:39\"],\"day\":[\"1\",\"多云\",\"34\",\"东风\",\"微风\",\"05:36\"],\"night\":[\"1\",\"多云\",\"26\",\"东北风\",\"3-4 级\",\"18:37\"]},\"week\":\"四\",\"nongli\":\"七月廿三\"},{\"date\":\"2016-08-26\",\"info\":{\"dawn\":[\"1\",\"多云\",\"26\",\"东北风\",\"3-4 级\",\"18:37\"],\"day\":[\"2\",\"阴\",\"31\",\"东北风\",\"4-5 级\",\"05:36\"],\"night\":[\"1\",\"多云\",\"24\",\"北风\",\"3-4 级\",\"18:36\"]},\"week\":\"五\",\"nongli\":\"七月廿四\"},{\"date\":\"2016-08-27\",\"info\":{\"dawn\":[\"1\",\"多云\",\"24\",\"北风\",\"3-4 级\",\"18:36\"],\"day\":[\"1\",\"多云\",\"30\",\"东北风\",\"3-4 级\",\"05:37\"],\"night\":[\"1\",\"多云\",\"20\",\"北风\",\"3-4 级\",\"18:35\"]},\"week\":\"六\",\"nongli\":\"七月廿五\"}],\"pm25\":{\"key\":\"Nanjing\",\"show_desc\":0,\"pm25\":{\"curPm\":\"48\",\"pm25\":\"26\",\"pm10\":\"47\",\"level\":1,\"quality\":\"优\",\"des\":\"可正常活动。\"},\"dateTime\":\"2016年08月23日06时\",\"cityName\":\"南京\"},\"jingqu\":\"\",\"date\":\"\",\"isForeign\":\"0\"}},\"error_code\":0}");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}

package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class bj_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json; charset=utf-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("{\"reason\":\"successed!\",\"result\":{\"data\":{\"realtime\":{\"city_code\":\"101010100\",\"city_name\":\"北京\",\"date\":\"2016-08-23\",\"time\":\"07:00:00\",\"week\":2,\"moon\":\"七月廿一\",\"dataUptime\":1471907834,\"weather\":{\"temperature\":\"24\",\"humidity\":\"81\",\"info\":\"阴\",\"img\":\"2\"},\"wind\":{\"direct\":\"南风\",\"power\":\"2级\",\"offset\":null,\"windspeed\":null}},\"life\":{\"date\":\"2016-8-23\",\"info\":{\"chuanyi\":[\"热\",\"天气热，建议着短裙、短裤、短薄外套、T恤等夏季服装。\"],\"ganmao\":[\"少发\",\"各项气象条件适宜，发生感冒机率较低。但请避免长期处于空调房间中，以防感冒。\"],\"kongtiao\":[\"部分时间开启\",\"天气热，到中午的时候您将会感到有点热，因此建议在午后较热时开启制冷空调。\"],\"wuran\":[\"良\",\"气象条件有利于空气污染物稀释、扩散和清除，可在室外正常活动。\"],\"xiche\":[\"不宜\",\"不宜洗车，未来24小时内有雨，如果在此期间洗车，雨水和路上的泥水可能会再次弄脏您的爱车。\"],\"yundong\":[\"较不宜\",\"有降水，推荐您在室内进行低强度运动；若坚持户外运动，须注意选择避雨防滑地点，并携带雨具。\"],\"ziwaixian\":[\"中等\",\"属中等强度紫外线辐射天气，外出时建议涂擦SPF高于15、PA+的防晒护肤品，戴帽子、太阳镜。\"]}},\"weather\":[{\"date\":\"2016-08-23\",\"info\":{\"day\":[\"3\",\"阵雨\",\"30\",\"\",\"微风\",\"05:34\"],\"night\":[\"3\",\"阵雨\",\"24\",\"\",\"微风\",\"18:59\"]},\"week\":\"二\",\"nongli\":\"七月廿一\"},{\"date\":\"2016-08-24\",\"info\":{\"dawn\":[\"3\",\"阵雨\",\"24\",\"无持续风向\",\"微风\",\"18:59\"],\"day\":[\"2\",\"阴\",\"31\",\"\",\"微风\",\"05:35\"],\"night\":[\"3\",\"阵雨\",\"23\",\"北风\",\"3-4 级\",\"18:58\"]},\"week\":\"三\",\"nongli\":\"七月廿二\"},{\"date\":\"2016-08-25\",\"info\":{\"dawn\":[\"3\",\"阵雨\",\"23\",\"北风\",\"3-4 级\",\"18:58\"],\"day\":[\"1\",\"多云\",\"30\",\"北风\",\"3-4 级\",\"05:36\"],\"night\":[\"0\",\"晴\",\"19\",\"\",\"微风\",\"18:56\"]},\"week\":\"四\",\"nongli\":\"七月廿三\"},{\"date\":\"2016-08-26\",\"info\":{\"dawn\":[\"0\",\"晴\",\"19\",\"无持续风向\",\"微风\",\"18:56\"],\"day\":[\"0\",\"晴\",\"29\",\"\",\"微风\",\"05:36\"],\"night\":[\"0\",\"晴\",\"18\",\"\",\"微风\",\"18:55\"]},\"week\":\"五\",\"nongli\":\"七月廿四\"},{\"date\":\"2016-08-27\",\"info\":{\"dawn\":[\"0\",\"晴\",\"18\",\"无持续风向\",\"微风\",\"18:55\"],\"day\":[\"0\",\"晴\",\"29\",\"\",\"微风\",\"05:37\"],\"night\":[\"0\",\"晴\",\"17\",\"\",\"微风\",\"18:53\"]},\"week\":\"六\",\"nongli\":\"七月廿五\"}],\"pm25\":{\"key\":\"Beijing\",\"show_desc\":0,\"pm25\":{\"curPm\":\"92\",\"pm25\":\"68\",\"pm10\":\"84\",\"level\":2,\"quality\":\"良\",\"des\":\"可以接受的，除极少数对某种污染物特别敏感的人以外，对公众健康没有危害。\"},\"dateTime\":\"2016年08月23日06时\",\"cityName\":\"北京\"},\"jingqu\":\"\",\"date\":\"\",\"isForeign\":\"0\"}},\"error_code\":0}");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}

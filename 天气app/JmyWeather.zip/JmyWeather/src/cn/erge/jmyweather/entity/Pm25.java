package cn.erge.jmyweather.entity;

public class Pm25 {

}

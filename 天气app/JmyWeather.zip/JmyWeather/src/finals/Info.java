package finals;

import java.util.List;

public class Info {
	private List<Kongtiao> kongtiao;

	private List<Yundong> yundong;

	private List<Ziwaixian> ziwaixian;

	private List<Ganmao> ganmao;

	private List<Xiche> xiche;

	private List<Wuran> wuran;

	private List<Chuanyi> chuanyi;

	public void setKongtiao(List<Kongtiao> kongtiao) {
		this.kongtiao = kongtiao;
	}

	public List<Kongtiao> getKongtiao() {
		return this.kongtiao;
	}

	public void setYundong(List<Yundong> yundong) {
		this.yundong = yundong;
	}

	public List<Yundong> getYundong() {
		return this.yundong;
	}

	public void setZiwaixian(List<Ziwaixian> ziwaixian) {
		this.ziwaixian = ziwaixian;
	}

	public List<Ziwaixian> getZiwaixian() {
		return this.ziwaixian;
	}

	public void setGanmao(List<Ganmao> ganmao) {
		this.ganmao = ganmao;
	}

	public List<Ganmao> getGanmao() {
		return this.ganmao;
	}

	public void setXiche(List<Xiche> xiche) {
		this.xiche = xiche;
	}

	public List<Xiche> getXiche() {
		return this.xiche;
	}

	public void setWuran(List<Wuran> wuran) {
		this.wuran = wuran;
	}

	public List<Wuran> getWuran() {
		return this.wuran;
	}

	public void setChuanyi(List<Chuanyi> chuanyi) {
		this.chuanyi = chuanyi;
	}

	public List<Chuanyi> getChuanyi() {
		return this.chuanyi;
	}
}

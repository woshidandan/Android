package finals;

public class Weather1 {
	private String date;

	private Info1 info;

	private String week;

	private String nongli;

	public void setDate(String date){
	this.date = date;
	}
	public String getDate(){
	return this.date;
	}
	public void setInfo(Info1 info){
	this.info = info;
	}
	public Info1 getInfo(){
	return this.info;
	}
	public void setWeek(String week){
	this.week = week;
	}
	public String getWeek(){
	return this.week;
	}
	public void setNongli(String nongli){
	this.nongli = nongli;
	}
	public String getNongli(){
	return this.nongli;
	}
}

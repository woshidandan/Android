package finals;

public class Result {
	private Data data;

	public void setData(Data data){
	this.data = data;
	}
	public Data getData(){
	return this.data;
	}
}

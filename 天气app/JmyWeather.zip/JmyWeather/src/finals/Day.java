package finals;

public class Day {

}
